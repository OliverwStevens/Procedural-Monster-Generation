using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToSpawn : MonoBehaviour
{
    public GameObject Creature;
    public AudioSource source;
    public GameObject Indicator;


    GameObject indicator;

    RaycastHit examine;
    MeshRenderer meshRenderer;
    private void Start()
    {
        indicator = Instantiate(Indicator, transform.position, Quaternion.identity);
        meshRenderer = indicator.GetComponent<MeshRenderer>();

    }
    // Update is called once per frame
    void Update()
    {
        Ray interest = Camera.main.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0));
        if (Physics.Raycast(interest, out examine, 20))
        {

            indicator.SetActive(true);
            if (Input.GetMouseButtonDown(0))
            {
                if (source != null)
                {
                    source.Play();

                }

                Vector3 SpawnPoint = new Vector3(examine.point.x, examine.point.y + 25, examine.point.z);
                Instantiate(Creature, SpawnPoint, Quaternion.identity);
                meshRenderer.material.color = Color.red;
            }
            else
            {
                meshRenderer.material.color = Color.green;
            }
            meshRenderer.transform.position = examine.point;
        }
        else
        {
            indicator.SetActive(false);
        }

    }


   
}
