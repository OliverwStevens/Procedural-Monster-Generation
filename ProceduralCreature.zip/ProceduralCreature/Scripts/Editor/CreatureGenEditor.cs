using UnityEditor;

[CustomEditor(typeof(CreatureGen))]
public class CreatureGenEditor : Editor
{
    #region SerializedProperties
    SerializedProperty Prevab;
    SerializedProperty EmptyPrevab;
    SerializedProperty DamageLayer;
    SerializedProperty ChildColliders;
    SerializedProperty scale;
    SerializedProperty scaleRange;
    SerializedProperty uniformPartsScale;
    SerializedProperty SegmentsRange;
    SerializedProperty LegNumber;
    SerializedProperty Tailchance;
    SerializedProperty Armchance;

    SerializedProperty LegStance;
    SerializedProperty massMultiplier;
    SerializedProperty colorVariation;
    SerializedProperty uniformColor;
    SerializedProperty bodyParts;
    SerializedProperty creatureAudio;


    SerializedProperty colorGradient;


    SerializedProperty LegDampen;
    SerializedProperty RelativeStepDistance;

    SerializedProperty prebuiltAI;

    SerializedProperty creatureAI;
    




    
    #endregion

    bool ScaleGroup, ColorGroup, SpecGroup = false;



    public void OnEnable()
    {
        Prevab = serializedObject.FindProperty("Prevab");
        EmptyPrevab = serializedObject.FindProperty("EmptyPrevab");
        DamageLayer = serializedObject.FindProperty("DamageLayer");
        ChildColliders = serializedObject.FindProperty("ChildColliders");

        scale = serializedObject.FindProperty("scale");
        scaleRange = serializedObject.FindProperty("scaleRange");
        uniformPartsScale = serializedObject.FindProperty("uniformPartsScale");
        SegmentsRange = serializedObject.FindProperty("SegmentsRange");
        LegNumber = serializedObject.FindProperty("LegNumber");
        Tailchance = serializedObject.FindProperty("Tailchance");
        Armchance = serializedObject.FindProperty("Armchance");

        LegStance = serializedObject.FindProperty("LegStance");
        LegDampen = serializedObject.FindProperty("LegDampen");
        RelativeStepDistance = serializedObject.FindProperty("RelativeStepDistance");

        massMultiplier = serializedObject.FindProperty("massMultiplier");



        colorGradient = serializedObject.FindProperty("colorGradient");



        colorVariation = serializedObject.FindProperty("colorVariation");
        uniformColor = serializedObject.FindProperty("uniformColor");

        //partsDictionary = serializedObject.FindProperty("partsDictionary");
        bodyParts = serializedObject.FindProperty("bodyParts");
        creatureAudio = serializedObject.FindProperty("creatureAudio");

        //creatureBehavior = serializedObject.FindProperty("creatureBehavior");
        prebuiltAI = serializedObject.FindProperty("prebuiltAI");


        creatureAI = serializedObject.FindProperty("creatureAI");
        




    }
    public override void OnInspectorGUI()
    {
        CreatureGen _toSpawn = (CreatureGen)target;



        serializedObject.Update();

        EditorGUILayout.PropertyField(Prevab);
        EditorGUILayout.PropertyField(EmptyPrevab);
        EditorGUILayout.PropertyField(DamageLayer);
        EditorGUILayout.PropertyField(ChildColliders);



        ScaleGroup = EditorGUILayout.BeginFoldoutHeaderGroup(ScaleGroup, "Scaling");
        if (ScaleGroup)
        {
            EditorGUILayout.PropertyField(scale);
            EditorGUILayout.PropertyField(scaleRange);
            EditorGUILayout.PropertyField(uniformPartsScale);
           
            
            EditorGUILayout.PropertyField(LegStance);
            EditorGUILayout.PropertyField(LegDampen);
            EditorGUILayout.PropertyField(RelativeStepDistance);

            
            EditorGUILayout.PropertyField(massMultiplier);
        }

        EditorGUILayout.EndFoldoutHeaderGroup();

        SpecGroup = EditorGUILayout.BeginFoldoutHeaderGroup(SpecGroup, "Specifications");

        if (SpecGroup)
        {
            EditorGUILayout.PropertyField(SegmentsRange);
            EditorGUILayout.PropertyField(LegNumber);
            EditorGUILayout.PropertyField(Armchance);
            EditorGUILayout.PropertyField(Tailchance);

        }


        EditorGUILayout.EndFoldoutHeaderGroup();


        ColorGroup = EditorGUILayout.BeginFoldoutHeaderGroup(ColorGroup, "Coloring");

        if (ColorGroup)
        {
            EditorGUILayout.PropertyField(colorVariation);
            if (_toSpawn.colorVariation)
            {
                EditorGUILayout.PropertyField(colorGradient);

                
                EditorGUILayout.PropertyField(uniformColor);
            }
        }

        EditorGUILayout.EndFoldoutHeaderGroup();


        EditorGUILayout.PropertyField(bodyParts);

        EditorGUILayout.PropertyField(creatureAudio);



        EditorGUILayout.PropertyField(prebuiltAI);
        if (_toSpawn.prebuiltAI)
        {
            EditorGUILayout.PropertyField(creatureAI);

        }
        serializedObject.ApplyModifiedProperties();
    }
}
