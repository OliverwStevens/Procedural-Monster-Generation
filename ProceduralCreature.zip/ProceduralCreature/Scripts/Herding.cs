using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Herding : MonoBehaviour
{
   public List<PreBuilt> builds = new List<PreBuilt>();

    void Update()
    {
        if (builds.Count <= 0)
        {
            Destroy(gameObject);
        }
    }
}
