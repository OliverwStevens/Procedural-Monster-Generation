using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class AudioManagement : MonoBehaviour
{
    [System.Serializable]
    public class SoundChannel
    {
        public int channelId;
        public List<AudioSource> audioSources = new List<AudioSource>();
        public Queue<AudioSource> availableSources = new Queue<AudioSource>();
        public List<AudioSource> playingSources = new List<AudioSource>();
        public int maxConcurrentSounds = 3;
    }

    public List<SoundChannel> soundChannels = new List<SoundChannel>();


    //You can add main volume controls so that source.volume = volume * MasterVolume * effectsVolume;
    void Start()
    {
        foreach (SoundChannel channel in soundChannels)
        {
            foreach (AudioSource source in channel.audioSources)
            {
                channel.availableSources.Enqueue(source);
            }
        }
    }

    public void PlaySound(AudioClip clip, GameObject targetObject, int channelId, float volume)
    {
        SoundChannel channel = soundChannels.Find(c => c.channelId == channelId);

        if (channel != null && channel.playingSources.Count < channel.maxConcurrentSounds)
        {
            AudioSource source = targetObject.GetComponent<AudioSource>();
            if (source != null && channel.availableSources.Contains(source))
            {
                source.volume = volume;
                source.clip = clip;
                source.Play();
                channel.playingSources.Add(source);
                StartCoroutine(WaitForSoundToFinish(channel, source));
            }
        }
    }

    IEnumerator WaitForSoundToFinish(SoundChannel channel, AudioSource source)
    {
        yield return new WaitForSeconds(source.clip.length);
        if (source == null)
        {
            channel.playingSources.Remove(source);
            yield break;
        }
        source.Stop();
        source.clip = null;
        channel.availableSources.Enqueue(source);
        channel.playingSources.Remove(source);
    }

    public void StopSound(GameObject targetObject, int channelId)
    {
        SoundChannel channel = soundChannels.Find(c => c.channelId == channelId);

        if (channel != null)
        {
            AudioSource source = targetObject.GetComponent<AudioSource>();
            if (source != null && source.isPlaying)
            {
                source.Stop();
                source.clip = null;
                channel.playingSources.Remove(source);
            }
        }
    }

    public void AddAudioSource(AudioSource newSource, int channelId)
    {
        SoundChannel channel = soundChannels.Find(c => c.channelId == channelId);

        if (channel != null)
        {
            channel.audioSources.Add(newSource);
            channel.availableSources.Enqueue(newSource);
        }
    }
}
