using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class PreBuilt : MonoBehaviour
{
    #region Variables
    LimbManager limbManager;

    Transform NeckControl;
    Transform TailControl;

    Transform RightArm, LeftArm;
    GameObject Head;

    public Rigidbody rb;
    private float timeOffset;

    Animator face;
    int state = Animator.StringToHash("State");
    int toState = 0;



    bool herding = true;

    public CreatureAI creatureAI;

    public List<PreBuilt> herdMates = new List<PreBuilt>();
    List <Transform> herdPos = new List<Transform>();
    private Transform Target;
    bool Attacking = false;


    [HideInInspector]
    public GameObject TailEnd;
    bool Searching = false;
    Vector3 newPosition;
    List<Transform> transforms = new List<Transform>();
    Bounds self;
    BoxCollider box;
    public float Speed;
    float awarenessScaleSquared;


    public AudioSource audiosourceM;


    public AudioManagement audioManagement;
    Transform Player;


    public CreatureAudio creatureAudio;

    int initialHp;
    private Vector3 randomDirection = new Vector3(1, 0,1);
    public float changeDirectionInterval = 10f;

    private float nextDirectionChangeTime;
    #endregion

    void Start()
    {



        limbManager = GetComponentInChildren<LimbManager>();
        NeckControl = limbManager.NeckTarget;
        TailControl = limbManager.TailTarget;


        RightArm = limbManager.RightArm;
        LeftArm = limbManager.LeftArm;


        Head = limbManager.Head;
        face = Head.GetComponent<Animator>();





        rb = GetComponent<Rigidbody>();



        timeOffset = Random.Range(0f, 2f * Mathf.PI);


        newPosition = NeckControl.localPosition;

        int herdSize = Mathf.RoundToInt(Random.Range(creatureAI.RelativeHerdSize.x, creatureAI.RelativeHerdSize.y));

        box = GetComponent<BoxCollider>();
        self = box.bounds;
        if (herding)
        {
            if (herdSize > 0)
            {
                GameObject HerdManager = Instantiate(limbManager.Empty, transform.position, Quaternion.identity);
                Herding manager = HerdManager.AddComponent<Herding>();

                manager.builds.Add(this);
                transforms.Add(transform);

                for (int i = 0; i < herdSize; i++)
                {
                    Vector3 spawnPos = new Vector3(10 * (i +1), 0, 0);
                    //copy gameobject
                    GameObject copy = Instantiate(gameObject, transform.position + spawnPos, Quaternion.identity);
                    PreBuilt C = copy.GetComponent<PreBuilt>();
                    C.herding = false;
                    manager.builds.Add(copy.transform.GetComponent<PreBuilt>());
                    transforms.Add(copy.transform);
                    if (C.TailEnd != null)
                    {
                        Destroy(C.TailEnd);
                    }
                }

                foreach (PreBuilt t in manager.builds)
                {
                    //prebuilts
                    t.herdMates = manager.builds;

                    //transforms
                    t.herdPos = transforms;
                }
            }
            else
            {
                herdPos.Add(transform);
            }

        }
        


        awarenessScaleSquared = creatureAI.AwarenessScale * creatureAI.AwarenessScale * 4;

        audioManagement = GameObject.Find("AudioManager").GetComponent<AudioManagement>();
        audioManagement.AddAudioSource(audiosourceM, 0);

        Player = GameObject.FindWithTag(creatureAudio.Player).transform;

        StartCoroutine(PlayRandomSounds());

        initialHp = creatureAI.HP;
    }

    void Update()
    {

        if (Target == null)
        {
            if (!Searching)
            {
                Searching = true;

                StartCoroutine(DetectNearbyEnemies());
            }
            Speed = creatureAI.Speed;

        }
        else
        {
            Speed= creatureAI.SprintSpeed;
            if ((transform.position - Target.position).sqrMagnitude > awarenessScaleSquared)
            {
                Target = null;
            }

        }


        NeckLerp();
        TailLerp();
        ArmLerp(RightArm);
        ArmLerp(LeftArm);

    }

    void FixedUpdate()
    {
        if (herdMates.Count > 1)
        {
            #region Herding
            Vector3 separation = Vector3.zero;
            Vector3 alignment = Vector3.zero;
            Vector3 cohesion = Vector3.zero;
            int countSeparation = 0;
            int countAlignment = 0;
            int countCohesion = 0;

            foreach (PreBuilt herdMate in herdMates)
            {

                if (herdMate != this && herdMate != null)
                {
                    Vector3 offset = transform.position - herdMate.transform.position;
                    float distance = offset.sqrMagnitude;

                    if (distance < creatureAI.separationDistance * creatureAI.separationDistance)
                    {

                        // Apply a falloff factor to reduce the strength of separation when close
                        float falloff = 1.0f - (distance / (creatureAI.separationDistance * creatureAI.separationDistance));
                        falloff = Mathf.Clamp01(falloff);

                        separation += offset.normalized * falloff;
                    }

                    if (distance < creatureAI.alignmentDistance * creatureAI.alignmentDistance)
                    {
                        alignment += herdMate.rb.velocity;
                        countAlignment++;
                    }

                    if (distance < creatureAI.cohesionDistance * creatureAI.cohesionDistance)
                    {
                        cohesion += herdMate.transform.position;
                        countCohesion++;
                    }
                }
            }

            if (countSeparation > 0)
            {
                separation /= countSeparation;
            }

            if (countAlignment > 0)
            {
                alignment /= countAlignment;
            }

            if (countCohesion > 0)
            {
                cohesion /= countCohesion;
                cohesion = (cohesion - transform.position).normalized;
            }

            Vector3 to = Vector3.zero;
            if (Target != null)
            {
                Vector3 toPlayer = Target.position - transform.position;

                if (creatureAI.predator)
                {

                    if (toPlayer.sqrMagnitude < (creatureAI.AwarenessScale/2) * (creatureAI.AwarenessScale / 2) && !Attacking)
                    {
                        Attacking = true;
                        Invoke("Attack", 5);

                        PreBuilt hp = Target.GetComponent<PreBuilt>();
                        if (hp != null)
                        {
                            hp.Hurt(creatureAI.damageDealt);
                        }
                    }
                }
                else
                {
                    if (toPlayer.sqrMagnitude < creatureAI.AwarenessScale * creatureAI.AwarenessScale)
                    {
                        toPlayer *= -1;
                        cohesion *= 0;
                    }
                    if (creatureAI.GoRogue)
                    {
                        if (creatureAI.HP < initialHp / 2)
                        {
                            creatureAI.predator = true;
                        }
                    }   
                }
                to = toPlayer;
            }
            // Combine the forces with desired weights
            Vector3 velocity = rb.velocity;

            if (Attacking == false)
            {
                velocity += separation * 8f + alignment + cohesion * 1.0f + to;
            }
            else
            {
                velocity += to * Speed;
            }


            // Limit the speed

            if (velocity.sqrMagnitude > Speed * Speed)
            {
                velocity = velocity.normalized * Speed;
            }

            if (velocity.sqrMagnitude > 1)
            {
                Quaternion targetRotation = Quaternion.LookRotation(velocity);
                Quaternion TargetRot = Quaternion.Euler(0, targetRotation.eulerAngles.y, 0);
                transform.rotation = Quaternion.Lerp(transform.rotation, TargetRot, creatureAI.turnSpeed);

            }

            rb.velocity = new Vector3(velocity.x, rb.velocity.y, velocity.z);
            
            #endregion
        }
        else
        {
            Vector3 to = Vector3.zero;
            if (Target != null)
            {
                Vector3 toPlayer = Target.position - transform.position;

                if (creatureAI.predator)
                {

                    if (toPlayer.sqrMagnitude < (creatureAI.AwarenessScale / 2) * (creatureAI.AwarenessScale / 2) && !Attacking)
                    {
                        Attacking = true;
                        Invoke("Attack", 5);

                        PreBuilt hp = Target.GetComponent<PreBuilt>();
                        if (hp != null)
                        {
                            hp.Hurt(creatureAI.damageDealt);
                        }
                    }
                }
                else
                {
                    if (toPlayer.sqrMagnitude < creatureAI.AwarenessScale * creatureAI.AwarenessScale)
                    {
                        toPlayer *= -1;
                    }
                    if (creatureAI.GoRogue)
                    {
                        if (creatureAI.HP < initialHp / 2)
                        {
                            creatureAI.predator = true;
                        }
                    }

                }
                to = toPlayer;
            }
            else
            {
                to = randomDirection;

                // Check if it's time to choose a new random direction
                if (Time.time >= nextDirectionChangeTime)
                {
                    ChooseNewRandomDirection();
                }
            }
            // Combine the forces with desired weights
            Vector3 velocity = rb.velocity + to * Speed;

            // Limit the speed

            if (velocity.sqrMagnitude > Speed * Speed)
            {
                velocity = velocity.normalized * Speed;
            }

            if (velocity.sqrMagnitude > 1)
            {
                Quaternion targetRotation = Quaternion.LookRotation(velocity);
                Quaternion TargetRot = Quaternion.Euler(0, targetRotation.eulerAngles.y, 0);
                transform.rotation = Quaternion.Lerp(transform.rotation, TargetRot, creatureAI.turnSpeed);
            }

            rb.velocity = new Vector3(velocity.x, rb.velocity.y, velocity.z);
        }






    }




    //Call this method in whatever script you want, for example when a bullet collides with this creature
    public void Hurt(int damage)
    {
        creatureAI.HP -= damage;

        audiosourceM.pitch = Random.Range(creatureAudio.PitchRange.x, creatureAudio.PitchRange.y);
        Sound(creatureAudio.Pain, gameObject, 0);

        if (creatureAI.HP <= 0)
        {
            Destroy(gameObject, 1);
        }

        // You can add XP to the player or something here, or instantiate a dropped item or something.

        //Simple spawning system setup

        //    AnimalSpawning.AnimalCount--;

    }
    IEnumerator PlayRandomSounds()
    {
        while (true)
        {
            float newInterval = Random.Range(creatureAudio.Interval.x, creatureAudio.Interval.y);

            // Wait for the specified interval
            yield return new WaitForSeconds(newInterval);

            audiosourceM.pitch = Random.Range(creatureAudio.PitchRange.x, creatureAudio.PitchRange.y);
            Sound(creatureAudio.Roar, gameObject, 0);
        }
    }
    void NeckLerp()
    {
        if (Attacking && creatureAI.predator)
        {
            if (Target != null)
            {
                NeckControl.position = Target.position;
            }
            Animation(1);

        }
        else
        {
            float neckY = Mathf.Sin(Time.time + timeOffset);
            newPosition.y = neckY;
            Animation(0);

        }

        if (Target == null)
        {
            NeckControl.localPosition = newPosition;
            Head.transform.rotation = Quaternion.Euler(0, transform.rotation.eulerAngles.y, 0);
        }
        else if (creatureAI.predator)
        {
            Head.transform.LookAt(Target.position);
        }
    }
    void TailLerp()
    {
        if (TailControl != null)
        {
            float TailX = Mathf.Sin(1 * Time.time + timeOffset);
            Vector3 newPosition = TailControl.localPosition;
            newPosition.x = TailX;
            TailControl.localPosition = newPosition;
        }
        
    }
    void ArmLerp(Transform arm)
    {
        if (arm != null)
        {
            if (Attacking)
            {
                if (Target != null)
                {
                    arm.position = Target.position;
                }
            }
            else
            {
                float ArmY = Mathf.Sin(Time.time) * .3f - 1;
                Vector3 newPosition = arm.transform.localPosition;
                newPosition.y = ArmY;
                arm.localPosition = newPosition;

            }
        }
        
       
    }

    void Attack()
    {
        Attacking = false;
    }
    void Animation(int _toState)
    {
        toState = _toState;
        if (toState != face.GetInteger(state))
        {
            face.SetInteger(state, toState);
            toState = face.GetInteger(state);
            //Idle = 0
            //Attack = 1            
        }
    }

    private IEnumerator DetectNearbyEnemies()
    {
        while (Target == null)
        {
            Collider[] colliders = Physics.OverlapSphere(transform.position, creatureAI.AwarenessScale);

            foreach (Collider collider in colliders)
            {
                GameObject colliderGameObject = collider.gameObject;

                if (!herdPos.Contains(collider.transform))
                {
                    foreach (string tag in creatureAI.Target)
                    {
                        if (colliderGameObject.CompareTag(tag))
                        {
                            Bounds en = colliderGameObject.GetComponent<Collider>().bounds;

                            if (en.size.sqrMagnitude > self.size.sqrMagnitude)
                            {
                                if (herdMates.Count > 0)
                                {
                                    foreach (PreBuilt p in herdMates)
                                    {
                                        p.creatureAI.predator = false;
                                        p.Target = colliderGameObject.transform;
                                    }
                                }
                                else
                                {
                                    creatureAI.predator = false;
                                    Target = colliderGameObject.transform;
                                }
                               
                            }
                            else
                            {
                                if (herdMates.Count > 0)
                                {
                                    foreach (PreBuilt p in herdMates)
                                    {
                                        p.creatureAI.predator = true;
                                        p.Target = colliderGameObject.transform;
                                    }
                                }
                                else
                                {
                                    creatureAI.predator = true;
                                    Target = colliderGameObject.transform;
                                }
                            }
                            yield return null;
                        }
                    }

                    if (Target != null)
                    {
                        Searching = false;
                        yield break; // Exit the outer loop and end the coroutine
                    }
                }
                
            }

            yield return new WaitForSeconds(2); // Wait for 2 seconds before checking again
        }
    }



    public void Sound(List<AudioClip> clips, GameObject _gameObject, int channel)
    {
        float dis = (transform.position - Player.position).sqrMagnitude;
        if (dis < creatureAudio.audioDistance * creatureAudio.audioDistance)
        {
            float volume = Mathf.Clamp01(1.0f - dis / (creatureAudio.audioDistance * creatureAudio.audioDistance));

            audioManagement.PlaySound(clips[Random.Range(0, clips.Count)], _gameObject, channel, volume);
        }
    }
  

    void ChooseNewRandomDirection()
    {
        // Generate a new random direction
        randomDirection = new Vector3(Random.Range(-1f, 1f), 0f, Random.Range(-1f, 1f)).normalized;

        // Set the next time to change direction
        nextDirectionChangeTime = Time.time + changeDirectionInterval;
    }

}

[System.Serializable]
public class CreatureAI
{

    public int HP;
    public int damageDealt;
    public float Speed;
    public float SprintSpeed;
    public float turnSpeed = 0.5f;
    public float AwarenessScale;


    public Vector2 RelativeHerdSize = new Vector2(0, 5);
    public float separationDistance = 2.0f;
    public float alignmentDistance = 5.0f;
    public float cohesionDistance = 5.0f;


    public bool predator = false;
    [Tooltip("Causes creature to defend itself at half health instead of trying to escape")]
    public bool GoRogue = false;
    [Tooltip("Enemy target tags")]
    public List<string> Target = new List<string>();
}
