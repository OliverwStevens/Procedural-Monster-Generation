using System.Collections.Generic;
using UnityEngine;

public class LimbManager : MonoBehaviour
{
    #region Variables
    public List<Transform> LegTargetPos = new List<Transform>();
    public List<Transform> InitialLegPos = new List<Transform>();
    List<Vector3> OldLegPos = new List<Vector3>();

    public List<Transform> ArmTargetPos = new List<Transform>();

    public float LegLength;
    public float StepDistance;

    [HideInInspector]
    public List<float> LegLerp = new List<float>();


    [HideInInspector]
    public Transform NeckTarget;

    [HideInInspector]
    public Transform TailTarget;

    [HideInInspector]
    public Transform LeftArm, RightArm;

    [HideInInspector]
    public GameObject Head;

    [HideInInspector]
    public float scale;

    [HideInInspector]
    public LayerMask Layer;
    //etc...
    bool isMoving = true;

    public float Theta = 15;
    public int layerMask;
    Rigidbody rb;

    public GameObject Empty;

    public float dampingFactor = 2;

    float currentAngle;

    Vector3 rayDirection1;
    Vector3 rayDirection2;

    public bool AINoise = false;
    PreBuilt preBuilt;
    AudioSource audiosourceF;

    #endregion
    private void Start()
    {
        rb = GetComponentInParent<Rigidbody>();
        layerMask = ~LayerMask.GetMask(LayerMask.LayerToName(Layer.value));

        SetInitialLegPos();

        currentAngle = Theta * Mathf.Deg2Rad;

        rayDirection1 = Vector3.down - new Vector3(Mathf.Cos(currentAngle), Mathf.Sin(-currentAngle), 0);
        rayDirection2 = Vector3.down + new Vector3(Mathf.Cos(currentAngle), Mathf.Sin(currentAngle), 0);

        if (AINoise)
        {
            preBuilt = transform.parent.GetComponent<PreBuilt>();
            audiosourceF = GetComponent<AudioSource>();
            preBuilt.audioManagement.AddAudioSource(audiosourceF, 1);
        }
    }
    void Update()
    {
        Legs();
    }

    #region Legs

    void Legs()
    {
        if (LegTargetPos.Count > 0)
        {
            for (int i = 0; i < LegTargetPos.Count; i++)
            {               
                Ray ray2;


                Vector3 worldRayDirection1 = transform.TransformDirection(rayDirection1);
                Vector3 worldRayDirection2 = transform.TransformDirection(rayDirection2);

                if (i % 2 == 0)
                {
                    ray2 = new Ray(InitialLegPos[i].position, worldRayDirection1);
                    Debug.DrawRay(ray2.origin, ray2.direction * LegLength, Color.blue);
                }
                else
                {
                    ray2 = new Ray(InitialLegPos[i].position, worldRayDirection2);
                    Debug.DrawRay(ray2.origin, ray2.direction * LegLength, Color.green);
                }

                if (Physics.Raycast(ray2, out RaycastHit hitInfo, LegLength, layerMask, QueryTriggerInteraction.Ignore))
                {
                    if (Vector3.Distance(LegTargetPos[i].position, hitInfo.point) > StepDistance && LegLerp[i] >= 1/rb.velocity.magnitude)
                    {
                        OldLegPos[i] = hitInfo.point;
                        LegLerp[i] = 0;

                        if (i < 2)
                        {
                            isMoving = !isMoving;
                        }

                        if (AINoise)
                        {
                            audiosourceF.pitch = Random.Range(preBuilt.creatureAudio.PitchRange.x, preBuilt.creatureAudio.PitchRange.y);
                            preBuilt.Sound(preBuilt.creatureAudio.FootStep, gameObject, 1);
                        }
                    }
                }

                if ((isMoving && i % 2 == 0) || (!isMoving && i % 2 != 0))
                {
                    MoveLeg(i, hitInfo);
                }
                else
                {
                    
                    LegTargetPos[i].position = OldLegPos[i];
                }

            }
        }
    }

    //Called from CreatureGen.cs
    public void SetInitialLegPos()
    {
        for (int i = 0;i < LegTargetPos.Count; i++)
        {
            Vector3 pos = new Vector3(LegTargetPos[i].position.x, transform.position.y, LegTargetPos[i].position.z);
            GameObject Raybuster = Instantiate(Empty, pos, Quaternion.identity, transform);


            InitialLegPos.Add(Raybuster.transform);
            OldLegPos.Add(LegTargetPos[i].position);
        }
    }

    void MoveLeg(int i, RaycastHit hitInfo)
    {

        if (LegLerp[i] < 1)
        {
            Vector3 lerping = Vector3.Lerp(OldLegPos[i], hitInfo.point, LegLerp[i]);
            lerping.y += Mathf.Sin(LegLerp[i] * Mathf.PI) * 2 * scale;

            // Apply damping to smooth out the movement
            Vector3 smoothedPosition = Vector3.Lerp(LegTargetPos[i].position, lerping, dampingFactor);
            LegTargetPos[i].position = smoothedPosition;

            LegLerp[i] += Time.deltaTime;
        }
        else
        {
            Vector3 smoothedPosition = Vector3.Lerp(LegTargetPos[i].position, OldLegPos[i], dampingFactor);

            LegTargetPos[i].position = smoothedPosition;
        }
    }

    #endregion
}
