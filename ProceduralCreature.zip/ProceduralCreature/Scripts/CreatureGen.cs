using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class CreatureGen : MonoBehaviour
{
    #region Variables
    public Transform Prevab;
    public GameObject EmptyPrevab;

    public string DamageLayer = "DamageLayer";
    public bool ChildColliders = true;

    public float scale = 1f;
    [Tooltip("0 = no random scale deviation, a random value between this NON-NEGATIVE value and its opposite will be added to scaleRange")]
    public float scaleRange = .1f;
    [Tooltip ("Utilizes Scale Range (Scale - ScaleRange needs to be greater than 0)")]
    public bool uniformPartsScale = false;

    [Tooltip("Positive Integers only, these need to be listed from smallest to greatest")]
    public Vector2 SegmentsRange = new Vector2(2, 4);

    public Vector2 LegNumber = new Vector2(2, 4);


    public float Tailchance = 75f;
    public float Armchance = 75f;

    [Tooltip("Width of stance in Degrees (list min to max)")]
    public Vector2 LegStance = new Vector2 (-90, -45);

    [Tooltip("Mass is calculated based on the box collider's size's magnitude")]
    public float massMultiplier = 1;

    [Tooltip("Creates random colors (Use a black and white texture for albedo) leave unchecked for consistent color")]
    public bool colorVariation = true;

    [Tooltip("Have a random main color otherwise have random colors")]
    public bool uniformColor = true;
    

    public Dictionary<string, List<GameObject>> partsDictionary = new Dictionary<string, List<GameObject>>();

    public Dictionary<string, List<AudioClip>> SoundDictionary = new Dictionary<string, List<AudioClip>>();

    MeshRenderer meshRenderer;

    public BodyParts bodyParts;
    public CreatureAudio creatureAudio;


    public ColorGradient colorGradient;

    public float LegDampen = 2;

    public float RelativeStepDistance = 5;
    Color colorRng;
   //AI
    public bool prebuiltAI = false;

    public CreatureAI creatureAI;

    List<GameObject> destruction = new List<GameObject>();

    #endregion

    void Start()
    {
        Generate();
    }

    void Generate()
    {
        #region Color Define

        colorRng = BlendGradients(colorGradient.color1, colorGradient.color2);
          
        #endregion



        scale += Scaling(scaleRange);


        int Mono = (Random.value < 0.5f) ? -1 : 1;


        AddToDictionary();

        GameObject Body = Instantiate(ToMake(partsDictionary["Body"]), Prevab.position, Quaternion.identity, Prevab);

        Body.transform.localScale *= scale;
        



        meshRenderer = Body.GetComponent<MeshRenderer>();

        Coloring(meshRenderer);




        Bounds bounds = meshRenderer.bounds;



        Vector3 localMin = Body.transform.InverseTransformPoint(bounds.min);
        Vector3 localMax = Body.transform.InverseTransformPoint(bounds.max);

        float bottomYPoint = localMin.y; // Bottom point in local coordinates
        float leftXPoint = localMin.x;   // Left point in local coordinates
        float rightXPoint = localMax.x;  // Right point in local coordinates
        float topYPoint = localMax.y;
        float FrontZPoint = localMax.z;
        float BackZPoint = localMin.z;



        #region Legs

        GameObject Leg = ToMake(partsDictionary["Leg"]);



        Leg.transform.localScale *= scale;

        List<Transform> Leglimbs = new List<Transform>();


        LimbManager limbManager = Body.AddComponent<LimbManager>();
        limbManager.scale = scale;


        MeshRenderer legRenderer = Leg.GetComponent<MeshRenderer>();

        Coloring(legRenderer);






        int numSegments = RNG(Mathf.RoundToInt(SegmentsRange.x), Mathf.RoundToInt(SegmentsRange.y));

        Bounds legBounds = legRenderer.bounds;
        float legTopYPoint = Leg.transform.InverseTransformPoint(legBounds.max).y;
        float legBotYPoint = Leg.transform.InverseTransformPoint(legBounds.min).y;

        float offset = (legTopYPoint - bottomYPoint) * .5f;





        GameObject LegSegment = ToMake(partsDictionary["LegSegment"]);

        MeshRenderer legSRenderer = LegSegment.GetComponent<MeshRenderer>();

        Coloring(legSRenderer);


        Bounds SegBounds = legSRenderer.bounds;

        float LgSegYTop = LegSegment.transform.InverseTransformPoint(SegBounds.max).y;
        float LgSegYDown = LegSegment.transform.InverseTransformPoint(SegBounds.min).y;

        float SegOffset = (LgSegYTop - LgSegYDown);
        float InitalSet = (LgSegYTop - legBotYPoint);


        int seed = Mathf.FloorToInt(Random.Range(LegNumber.x, LegNumber.y + 1) / 2) * 2;
        if (seed == 2)
        {
            //Biped
            Vector3 leftLegPos = new Vector3(leftXPoint, bottomYPoint - offset, 0);
            Vector3 rightLegPos = new Vector3(rightXPoint, bottomYPoint - offset, 0);

            GameObject leftLeg = Instantiate(Leg, Body.transform.TransformPoint(leftLegPos), Quaternion.identity, Prevab.transform);
            GameObject rightLeg = Instantiate(Leg, Body.transform.TransformPoint(rightLegPos), Quaternion.identity, Prevab.transform);
            
            Leglimbs.Add(leftLeg.transform);
            Leglimbs.Add(rightLeg.transform); 
        }
        else if(seed == 4)
        {
            //quad
            Vector3 leftLegF = new Vector3(leftXPoint, bottomYPoint - offset, FrontZPoint);
            Vector3 rightLegF = new Vector3(rightXPoint, bottomYPoint - offset, FrontZPoint);
            Vector3 leftLegB = new Vector3(leftXPoint, bottomYPoint - offset, BackZPoint);
            Vector3 rightLegB = new Vector3(rightXPoint, bottomYPoint - offset, BackZPoint);

            GameObject leftLgF = Instantiate(Leg, Body.transform.TransformPoint(leftLegF), Quaternion.identity, Prevab.transform);
            GameObject rightLgF = Instantiate(Leg, Body.transform.TransformPoint(rightLegF), Quaternion.identity, Prevab.transform);

            GameObject leftLgB = Instantiate(Leg, Body.transform.TransformPoint(leftLegB), Quaternion.identity, Prevab.transform);
            GameObject rightLgB = Instantiate(Leg, Body.transform.TransformPoint(rightLegB), Quaternion.identity, Prevab.transform);

            Leglimbs.Add(leftLgF.transform);
            Leglimbs.Add(rightLgF.transform);
            Leglimbs.Add(leftLgB.transform);
            Leglimbs.Add(rightLgB.transform);
        }

        foreach (Transform leg in Leglimbs)
        {
            for (int i = 0; i < numSegments; i++)
            {
                GameObject legSegment;
                legSegment = Instantiate(LegSegment, leg);
                if (i == 0)
                {
                    legSegment.transform.localPosition = new Vector3(0f, -InitalSet * (i + 1), 0f);

                }
                else
                {
                    //susy
                    legSegment.transform.localPosition = new Vector3(0f, (-SegOffset - InitalSet) * (i + 1) * .5f, 0f);






                }
            }
        }






        foreach (Transform leg in Leglimbs)
        {
            if (!uniformPartsScale)
            {
                for (int i = 0; i < leg.childCount; i++)
                {
                    Transform child = leg.GetChild(i);
                    int O = i + 1;

                    Vector3 legScale = new Vector3(Scaling(scaleRange)/O, 0, Scaling(scaleRange)/O);
                    child.transform.localScale += legScale;
                }
            }
            
            


            //create target
            //create empty
            //create pole
            Transform Last = leg.GetChild(leg.childCount - 1);
            MeshRenderer lastRenderer = Last.GetComponent<MeshRenderer>();
            Bounds lastbounds = lastRenderer.bounds;
            float foot = Last.transform.InverseTransformPoint(lastbounds.min).y;
            Vector3 placement = new Vector3(0, foot, 0);

            GameObject Empty = Instantiate(EmptyPrevab, Last.TransformPoint(placement), Quaternion.identity, Prevab.transform);
            Empty.name = "EndL";
            GameObject Target = Instantiate(EmptyPrevab, Empty.transform.position, Quaternion.identity, Prevab.transform);



            Target.name = "TargetL";
            IKSolver ik = Target.AddComponent<IKSolver>();
            ik.AssignLegBones(leg);
            ik.endPointOfLastBone = Empty.transform;

            
            Vector3 legHeight = (leg.transform.localPosition - Empty.transform.localPosition) /2;


            Vector3 polPos = new Vector3(leg.transform.localPosition.x, -legHeight.y, legHeight.y * Mono);


            GameObject pole = Instantiate(EmptyPrevab, Body.transform.TransformPoint(polPos), Quaternion.identity, Prevab.transform);
            pole.name = "pole";



            ik.poleTarget = pole.transform;
            ik.iterations = 50;
            limbManager.LegTargetPos.Add(Target.transform);
            float data = leg.transform.localPosition.y - Empty.transform.localPosition.y;
            limbManager.LegLength = 2 * data;
            limbManager.StepDistance = data * RelativeStepDistance * scale;

            limbManager.LegLerp.Add(1);
        }
        limbManager.Empty = EmptyPrevab;

        limbManager.Theta = Random.Range(LegStance.x, LegStance.y);
        #endregion

        //If there is ever trouble, check the orgins of neck segments
        #region Neck
        GameObject neck = ToMake(partsDictionary["NeckSegment"]);
        neck.transform.localScale *= scale;



        MeshRenderer neckRenderer = neck.GetComponent<MeshRenderer>();

        Coloring(neckRenderer);

        Bounds neckBounds = neckRenderer.bounds;
        float yNeckBottom = neck.transform.InverseTransformPoint(neckBounds.min).y;
        float yNeckTop = neck.transform.InverseTransformPoint(neckBounds.max).y;
     

        float offsetY = (yNeckTop - yNeckBottom) * scale;



        Vector3 NeckPos = new Vector3(0, topYPoint/2 - yNeckBottom, FrontZPoint);


        GameObject Neck = Instantiate(neck, Body.transform.TransformPoint(NeckPos), Quaternion.Euler(180,0,0), Prevab.transform);
       
        List<Transform> NeckSegments = new List<Transform>();

        NeckSegments.Add(Neck.transform);

        int NeckSegCount = RNG(1, Mathf.RoundToInt(Leglimbs.Count * 1.5f));

        for (int i = 0; i < NeckSegCount; i++)
        {
            GameObject NeckSegment = Instantiate(neck, Prevab.transform);
            NeckSegment.transform.localRotation = Neck.transform.localRotation;
            NeckSegment.transform.localPosition = new Vector3(0f, -offsetY * (i + 1) + Neck.transform.localPosition.y, Neck.transform.localPosition.z);
            NeckSegments.Add(NeckSegment.transform);

            int O = i + 1;

            Vector3 NeckScale = new Vector3(Scaling(scaleRange) / O, 0, Scaling(scaleRange) / O);
            NeckSegment.transform.localScale += NeckScale;


        }


        Transform LastN = NeckSegments[NeckSegments.Count -1];
        MeshRenderer lastRendererN = LastN.GetComponent<MeshRenderer>();
        Bounds lastboundsN = lastRendererN.bounds;
        float footN = LastN.transform.InverseTransformPoint(lastboundsN.max).y;
        Vector3 placementN = new Vector3(0, footN, 0);

        GameObject EmptyN = Instantiate(EmptyPrevab, LastN.TransformPoint(placementN), Quaternion.identity, Prevab.transform);
        EmptyN.name = "EndN";
        GameObject TargetN = Instantiate(EmptyPrevab, EmptyN.transform.position, Quaternion.identity, Prevab.transform);
        TargetN.name = "TargetN";
        IKSolver ikN = TargetN.AddComponent<IKSolver>();
       
        
        ikN.ListBones(NeckSegments);
        ikN.endPointOfLastBone = EmptyN.transform;


        Vector3 NHeight = (Neck.transform.localPosition - EmptyN.transform.localPosition) / 2;
        Vector3 polPosN = new Vector3(Neck.transform.localPosition.x, -NHeight.y, NHeight.y);
        GameObject poleN = Instantiate(EmptyPrevab, Body.transform.TransformPoint(polPosN), Quaternion.identity, Prevab.transform);
        poleN.name = "PoleN";



        ikN.poleTarget = poleN.transform;
        ikN.iterations = 10;

        limbManager.NeckTarget = TargetN.transform;

        TargetN.transform.localPosition = new Vector3(0, Body.transform.localPosition.y, NeckSegments.Count *2);
        #endregion

        #region Head

        Transform lastNSeg = NeckSegments[NeckSegments.Count - 1].transform;


        Vector3 HeadPos = new Vector3(0f, -offsetY * NeckSegments.Count + Neck.transform.localPosition.y, Neck.transform.localPosition.z);



        Quaternion headRot = Quaternion.Euler(90, 0, 0);

        GameObject head = Instantiate(ToMake(partsDictionary["Head"]), lastNSeg.position, headRot, Prevab.transform);

        if (colorVariation)
        {
            SkinnedMeshRenderer headRend = head.GetComponentInChildren<SkinnedMeshRenderer>();
            MeshRenderer headRend2 = head.GetComponentInChildren<MeshRenderer>();
            headRend.material.SetColor("_Color", colorRng);
            headRend2.material.SetColor("_Color", colorRng);
        }
      



        head.transform.localPosition = HeadPos;
        head.transform.localScale *= scale;
        head.transform.parent = lastNSeg.transform;

        limbManager.Head = head;




        #endregion

        #region Tail
        List<Transform> TailSegments = new List<Transform>();

        float randomValue = Random.Range(0f, 100f);
        if (randomValue <= Tailchance)
        {


            GameObject tail = ToMake(partsDictionary["TailSegment"]);
            tail.transform.localScale *= scale;



            MeshRenderer tailrenderer = tail.GetComponent<MeshRenderer>();

            Coloring(tailrenderer);

            Bounds tailbounds = tailrenderer.bounds;
            float yTailBottom = tail.transform.InverseTransformPoint(tailbounds.min).y;
            float yTailTop = tail.transform.InverseTransformPoint(tailbounds.max).y;


            float TailoffsetY = (yTailTop - yTailBottom) * scale;



            Vector3 TailPos = new Vector3(0, Random.Range(bottomYPoint, topYPoint) - yTailBottom, BackZPoint);


            GameObject Tail = Instantiate(tail, Body.transform.TransformPoint(TailPos), Quaternion.Euler(180, 0, 0), Prevab.transform);


            TailSegments.Add(Tail.transform);



            for (int i = 0; i < Leglimbs.Count * 1.5; i++)
            {
                GameObject TailSegment = Instantiate(tail, Prevab.transform);
                TailSegment.transform.localRotation = Tail.transform.localRotation;

                TailSegment.transform.localPosition = new Vector3(0f, -TailoffsetY * (i + 1) + Tail.transform.localPosition.y, Tail.transform.localPosition.z);
                TailSegments.Add(TailSegment.transform);

                int O = i + 1;

                Vector3 TailScale = new Vector3(Scaling(scaleRange) / O, 0, Scaling(scaleRange) / O);
                TailSegment.transform.localScale += TailScale;
            }



            Transform LastT = TailSegments[TailSegments.Count - 1];
            MeshRenderer lastRendererT = LastT.GetComponent<MeshRenderer>();
            Bounds lastboundsT = lastRendererT.bounds;
            float footT = LastT.transform.InverseTransformPoint(lastboundsT.max).y;
            Vector3 placementT = new Vector3(0, footT, 0);

            GameObject EmptyT = Instantiate(EmptyPrevab, LastT.TransformPoint(placementT), Quaternion.identity, Prevab.transform);
            EmptyT.name = "EndT";
            GameObject TargetT = Instantiate(EmptyPrevab, EmptyT.transform.position, Quaternion.identity, Prevab.transform);
            TargetT.name = "TargetT";
            IKSolver ikT = TargetT.AddComponent<IKSolver>();


            ikT.ListBones(TailSegments);
            ikT.endPointOfLastBone = EmptyT.transform;


            Vector3 THeight = (Tail.transform.localPosition - EmptyT.transform.localPosition) / 2;
            Vector3 polPosT = new Vector3(Tail.transform.localPosition.x, -THeight.y, -THeight.y);
            GameObject poleT = Instantiate(EmptyPrevab, Body.transform.TransformPoint(polPosT), Quaternion.identity, Prevab.transform);
            poleT.name = "PoleT";



            ikT.poleTarget = poleT.transform;
            ikT.iterations = 10;

            limbManager.TailTarget = TargetT.transform;

            TargetT.transform.localPosition = new Vector3(0, Body.transform.localPosition.y, -TailSegments.Count * 2);


            Destroy(LastT.gameObject);
        }

        #endregion

        #region Arms

        float ArandomValue = Random.Range(0f, 100f);

        if (ArandomValue <= Armchance)
        {
            GameObject Arm = ToMake(partsDictionary["Arm"]);
            Arm.transform.localScale *= scale;


            List<Transform> Arms = new List<Transform>();




            MeshRenderer ArmRenderer = Arm.GetComponent<MeshRenderer>();

            Coloring(ArmRenderer);

            Bounds ArmBounds = ArmRenderer.bounds;

            float ArmTopYPoint = Arm.transform.InverseTransformPoint(ArmBounds.max).y;
            float ArmBotYPoint = Arm.transform.InverseTransformPoint(ArmBounds.min).y;


            float ArmoffsetY = (ArmTopYPoint - bottomYPoint) * Random.Range(.5f, 1.75f);
            float ArmoffsetZ = Random.Range(BackZPoint * .7f, FrontZPoint * .7f);


            Vector3 leftArmPos = new Vector3(leftXPoint, topYPoint - ArmoffsetY, ArmoffsetZ);
            Vector3 rightArmPos = new Vector3(rightXPoint, topYPoint - ArmoffsetY, 0);

            GameObject leftArm = Instantiate(Arm, Body.transform.TransformPoint(leftArmPos), Quaternion.identity, Prevab.transform);
            GameObject rightArm = Instantiate(Arm, Body.transform.TransformPoint(rightArmPos), Quaternion.identity, Prevab.transform);



            Arms.Add(leftArm.transform);
            Arms.Add(rightArm.transform);


            GameObject ArmSegment = ToMake(partsDictionary["ArmSection"]);

            MeshRenderer ArmSRenderer = ArmSegment.GetComponent<MeshRenderer>();

            Coloring(ArmSRenderer);

            Bounds ASegBounds = ArmSRenderer.bounds;

            float ASegYTop = ArmSegment.transform.InverseTransformPoint(ASegBounds.max).y;
            float ASegYDown = ArmSegment.transform.InverseTransformPoint(ASegBounds.min).y;

            float ASegOffset = (ASegYTop - ASegYDown);
            float AInitalSet = (ASegYTop - ArmBotYPoint);


            foreach (Transform arm in Arms)
            {

                for (int i = 0; i < numSegments / 1.3f; i++)
                {
                    GameObject ASegment;
                    ASegment = Instantiate(ArmSegment, arm);

                    if (i == 0)
                    {
                        ASegment.transform.localPosition = new Vector3(0, -AInitalSet * (i + 1), 0f);

                    }
                    else
                    {
                        ASegment.transform.localPosition = new Vector3(0, (-ASegOffset - AInitalSet) * (i + 1) * .5f, 0f);

                        Vector3 ArmScale = new Vector3(Scaling(scaleRange) / i, 0, Scaling(scaleRange) / i);
                        ASegment.transform.localScale += ArmScale;
                    }
                    ASegment.name = "ArmSeg";



                }

                Transform ALast = arm.GetChild(arm.childCount - 1);
                MeshRenderer AlastRenderer = ALast.GetComponent<MeshRenderer>();
                Bounds Alastbounds = AlastRenderer.bounds;
                float Hand = ALast.transform.InverseTransformPoint(Alastbounds.min).y;
                Vector3 Aplacement = new Vector3(0, Hand, 0);

                GameObject AEmpty = Instantiate(EmptyPrevab, ALast.TransformPoint(Aplacement), Quaternion.identity, Prevab.transform);
                AEmpty.name = "AEnd";
                GameObject ATarget = Instantiate(EmptyPrevab, AEmpty.transform.position, Quaternion.identity, Prevab.transform);
                ATarget.name = "ATarget";
                IKSolver Aik = ATarget.AddComponent<IKSolver>();
                Aik.AssignLegBones(arm);
                Aik.endPointOfLastBone = AEmpty.transform;


                Vector3 ArmHeight = (arm.transform.localPosition - AEmpty.transform.localPosition) / 2;
                Vector3 ApolPos = new Vector3(arm.transform.localPosition.x * ArmHeight.y, arm.transform.localPosition.y, ArmHeight.y * Mono);
                GameObject Apole = Instantiate(EmptyPrevab, Body.transform.TransformPoint(ApolPos), Quaternion.identity, Prevab.transform);
                Apole.name = "Apole";
                arm.name = "Arm";


                Aik.poleTarget = Apole.transform;
                Aik.iterations = 50;

                if (arm == rightArm.transform)
                {
                    limbManager.RightArm = ATarget.transform;
                }
                else
                {
                    limbManager.LeftArm = ATarget.transform;
                }

                ATarget.transform.localPosition = new Vector3(arm.transform.localPosition.x * ArmHeight.y, Body.transform.localPosition.y, ArmHeight.y * (arm.childCount - 1) * .7f);

            }
        }
       






        #endregion



        #region Collider
        Body.AddComponent<BoxCollider>();
        Body.layer = LayerMask.NameToLayer(DamageLayer);

        if (ChildColliders)
        {
            List<Transform> childCol = new List<Transform>();
            childCol.AddRange(NeckSegments);
            childCol.AddRange(TailSegments);
        
            foreach (Transform child in childCol)
            {
                child.gameObject.AddComponent<BoxCollider>();
                child.gameObject.layer = LayerMask.NameToLayer(DamageLayer);
            }            
        }




        Rigidbody rb = Prevab.AddComponent<Rigidbody>();
        rb.constraints = RigidbodyConstraints.FreezeRotation;
        BoxCollider box = Prevab.AddComponent<BoxCollider>();


        Renderer[] renderers = Prevab.GetComponentsInChildren<Renderer>();
        Bounds boundz = new Bounds(renderers[0].bounds.center, Vector3.zero);

        // Calculate the bounds that encapsulate all child renderers
        foreach (Renderer rend in renderers)
        {
            boundz.Encapsulate(rend.bounds);           
        }



        float NKLength = offsetY * NeckSegments.Count;


        // Assign the bounds size to the collider
        box.center = boundz.center - transform.position; // Adjust for object position

        box.size = boundz.size;

        box.center = new Vector3(box.center.x, box.center.y - NHeight.y, box.center.z);

        
        box.size = new Vector3(box.size.x, box.size.y - (NKLength + NHeight.y) * .55f, box.size.z);

        float Mag = box.size.magnitude;
        rb.mass = Mag * massMultiplier;
        #endregion

        limbManager.Layer = transform.parent.gameObject.layer;
        limbManager.dampingFactor = LegDampen;


        #region Audio SetUp

        // This part is mostly reliant on having the prebuilt AI for obvious reasons
        AudioSource audioSource = Prevab.AddComponent<AudioSource>();
        Body.AddComponent<AudioSource>();
        #endregion


        if (prebuiltAI)
        {

            #region Stats


            PreBuilt prebuilt = Prevab.AddComponent<PreBuilt>();

            prebuilt.creatureAI = creatureAI;


            prebuilt.creatureAI.HP = Mathf.RoundToInt(creatureAI.HP + Scaling(Mag));
            prebuilt.creatureAI.damageDealt = Mathf.RoundToInt(creatureAI.damageDealt + Scaling(Mag));
            prebuilt.creatureAI.Speed = creatureAI.Speed + Mathf.Abs(Scaling(Mag/5));
            prebuilt.creatureAI.SprintSpeed = creatureAI.SprintSpeed + Mathf.Abs(Scaling(Mag / 5));

            prebuilt.creatureAI.Target = creatureAI.Target;
            prebuilt.creatureAI.RelativeHerdSize = creatureAI.RelativeHerdSize;
            prebuilt.creatureAI.predator = creatureAI.predator;
            prebuilt.creatureAI.AwarenessScale = creatureAI.AwarenessScale * box.size.y * 2;


            prebuilt.creatureAI.cohesionDistance = creatureAI.cohesionDistance * scale;
            prebuilt.creatureAI.alignmentDistance = creatureAI.alignmentDistance * scale;
            prebuilt.creatureAI.separationDistance = creatureAI.separationDistance * scale;

            if (TailSegments.Count > 0)
            {
                prebuilt.TailEnd = TailSegments[TailSegments.Count - 1].gameObject;
            }
            #endregion

            prebuilt.creatureAudio = creatureAudio;
            prebuilt.audiosourceM = audioSource;

            prebuilt.creatureAudio.FootStep = ToSoundList(SoundDictionary["Step"], creatureAudio.StepClipsCount);
            prebuilt.creatureAudio.Roar = ToSoundList(SoundDictionary["Roar"], creatureAudio.RoarClipsCount);
            prebuilt.creatureAudio.Pain = ToSoundList(SoundDictionary["Pain"], creatureAudio.PainClipsCount);


            prebuilt.creatureAudio.Player = creatureAudio.Player;
            prebuilt.creatureAudio.audioDistance = creatureAudio.audioDistance;
            prebuilt.creatureAudio.PitchRange = creatureAudio.PitchRange;
            prebuilt.creatureAI.GoRogue = creatureAI.GoRogue;
            limbManager.AINoise = true;
        }


        foreach (GameObject j in destruction)
        {
            Destroy(j);
        }




        Destroy(gameObject);

    }



    int RNG(int min, int max)
    {
       return Random.Range(min, max +1);
    }
    void AddToDictionary()
    {
        partsDictionary.Add("Body", bodyParts.Body);
        partsDictionary.Add("Leg", bodyParts.Hip);
        partsDictionary.Add("LegSegment", bodyParts.LegSegment);
        partsDictionary.Add("Arm", bodyParts.Shoulder);
        partsDictionary.Add("ArmSection", bodyParts.ArmSection);
        partsDictionary.Add("NeckSegment", bodyParts.NeckSegment);
        partsDictionary.Add("TailSegment", bodyParts.TailSegment);
        partsDictionary.Add("Head", bodyParts.Head);



        SoundDictionary.Add("Step", creatureAudio.FootStep);
        SoundDictionary.Add("Roar", creatureAudio.Roar);
        SoundDictionary.Add("Pain", creatureAudio.Pain);

    }

    GameObject ToMake(List<GameObject> partType)
    {
        GameObject newby = Instantiate(partType[Random.Range(0, partType.Count)]);
        destruction.Add(newby);
        return newby;
    }

    List<AudioClip> ToSoundList(List<AudioClip> clipType, int numberOfClips)
    {
        List<AudioClip> newClipList = new List<AudioClip>();

        if (clipType.Count == 0 || numberOfClips <= 0)
        {
            return newClipList;
        }

        if (numberOfClips > clipType.Count)
        {
            numberOfClips = clipType.Count;
        }

        List<AudioClip> availableClips = new List<AudioClip>(clipType);

        for (int i = 0; i < numberOfClips; i++)
        {
            int randomIndex = Random.Range(0, availableClips.Count);
            newClipList.Add(availableClips[randomIndex]);
            availableClips.RemoveAt(randomIndex);
        }

        return newClipList;
    }


    float Scaling(float value)
    {
        float scaled  = Random.Range(-value, value);
        return scaled;
    }

    void Coloring(MeshRenderer meshRend)
    {
        if (colorVariation)
        {
            if (uniformColor)
            {
                meshRend.material.SetColor("_Color", colorRng);
            }
            else
            {

                Color color = BlendGradients(colorGradient.color1, colorGradient.color2);
                meshRend.material.SetColor("_Color", color);
            }
        }
       
    }

    private Color BlendGradients(Gradient gradient1, Gradient gradient2)
    {
        float randomT = Random.Range(0f, 1f);
        Color resultColor = Color.Lerp(gradient1.Evaluate(randomT), gradient2.Evaluate(randomT), randomT);
        return resultColor;
    }

}
[System.Serializable]
public class BodyParts
{
    public List<GameObject> Body;
    public List<GameObject> Hip;
    public List<GameObject> LegSegment;
    public List<GameObject> Shoulder;
    public List<GameObject> ArmSection;
    public List<GameObject> NeckSegment;
    public List<GameObject> TailSegment;
    public List<GameObject> Head;
   
}

[System.Serializable]
public class CreatureAudio
{
    public List<AudioClip> FootStep;

    public List<AudioClip> Roar;

    public List<AudioClip> Pain;

    [Tooltip("Positive integer value for number of availble clips used by Prebuilt AI system")]
    public int StepClipsCount, RoarClipsCount, PainClipsCount;

    [Tooltip("Player's Tag for single-player audio listener")]
    public string Player;

    [Tooltip("Distance over which sound is carried")]
    public float audioDistance;

    [Tooltip("Random amount of time in seconds between roars")]
    public Vector2 Interval;

    [Tooltip("Proper use would be a positive small value for x, and a larger positive value for y (1,1) will result in no change ")]
    public Vector2 PitchRange;
}

[System.Serializable]
public class ColorGradient
{
    public Gradient color1;
    public Gradient color2;
}
